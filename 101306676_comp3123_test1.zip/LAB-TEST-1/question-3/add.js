//import fs module
const fs = require('fs')

//create a Logs directory if it does not exist
if(!fs.existsSync("Logs"))
    fs.mkdirSync("Logs")

//change the current process to the new Logs directory
process.chdir("Logs")

//create 10 log files and write some text into the file
for(let i = 0; i < 10; i++){ 
    const fileName = `log${i}.txt`
    const data = `This is log file #${i}`
    fs.writeFile(fileName, data, err => {
        if(err)
            console.log(err)
        else
            console.log("File written successfully!")
    })
    //output the file names to console
    console.log(fileName)
}