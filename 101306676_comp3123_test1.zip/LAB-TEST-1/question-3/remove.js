//import fs and path module
const fs = require('fs')
const path = require('path')

//check if Logs directory exists
if(fs.existsSync("Logs")){
    //read directory
    fs.readdir("Logs", (err, files) => {
        //throw error if fail to read directory
        if (err) {
            console.log(err)
        }
        //otherwise remove all files in directory
        else {    
            for (const file of files){
                const filePath = path.join("Logs", file)
                fs.unlink(filePath, err => {
                    if (err)
                        console.log(err)
                    else
                        //output the file nmes to delete
                        console.log(`delete files...${file}!`)
                })
            }
            // remove directory after deleting all files
            fs.rmdirSync("Logs") 
        }
    })
}