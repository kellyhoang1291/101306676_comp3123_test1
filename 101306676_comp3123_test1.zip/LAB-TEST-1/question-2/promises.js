const resolvePromise = () => new Promise((resolve, reject) => {
    setTimeout(resolve({'message': 'delayed success!'}), 500)
})

const rejectPromise = () => new Promise((resolve, reject) => {
    setTimeout(reject({'error': 'delayed exception!'}), 500)
})

resolvePromise().then(success => console.log(success))
rejectPromise().catch(error => console.log(error))