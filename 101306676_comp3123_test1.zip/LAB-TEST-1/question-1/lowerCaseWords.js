const mixedArray = ["PIZZA", 10, true, 25, false, "Wings"] //valid array
const invalidArray = [] //empty array
const invalidInput = 12 //not array

const lowerCaseWords = array => new Promise((resolve, reject) => {
        //check if is array and has at least 1 element
        if (Array.isArray(array) && array.length > 0){
            resolve(array.filter(word => isNaN(word)).map(word => word.toLowerCase()))
        } else {
            reject("Invalid input, non-empty array is expected!")
        }
    })


//function calls for valid, invalid arrays
lowerCaseWords(mixedArray).then(success => console.log(success))
  .catch(error => console.log(error))

lowerCaseWords(invalidArray).then(success => console.log(success))
  .catch(error => console.log(error))

lowerCaseWords(invalidInput).then(success => console.log(success))
  .catch(error => console.log(error))

